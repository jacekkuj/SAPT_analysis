unset PSIDATADIR
export PATH=/home/jacol/psi4conda/bin:$PATH
export PSI_SCRATCH=/tmp

psi4 -n 4 -i sapt0.in -o sapt0.out

